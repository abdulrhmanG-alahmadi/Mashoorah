package com.example.mashoorah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
